const express = require("express");
const path = require("path");
const app = express();
const PORT = process.env.PORT || 10000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_, res) => res.json({ok:true, name:"Fabio Exchange"}));

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Fabio Exchange running on port ${PORT}`);
});