const data={
  "Futebol":[
    {league:"Brasil • Campeonato Nacional",matches:[
      ["19:00","Flamengo","Palmeiras",[2.10,3.25,3.40]],
      ["21:30","Corinthians","Grêmio",[2.45,3.10,2.85]]
    ]},
    {league:"Europa • Liga Principal",matches:[
      ["16:00","Real Madrid","Barcelona",[2.20,3.60,2.70]],
      ["18:30","Liverpool","Arsenal",[1.95,3.70,3.50]]
    ]}
  ],
  "Basquete":[
    {league:"Brasil • Liga",matches:[
      ["20:00","Minas","Franca",[1.85,1.90]],
      ["21:30","Flamengo","Bauru",[1.72,2.05]]
    ]},
    {league:"EUA • Simulação",matches:[
      ["22:00","Lakers","Celtics",[2.10,1.75]],
      ["23:30","Warriors","Bulls",[1.65,2.20]]
    ]}
  ],
  "Tênis":[
    {league:"ATP • Simulação",matches:[
      ["14:00","Carlos Silva","João Santos",[1.80,2.05]],
      ["16:00","Pedro Lima","Lucas Costa",[2.25,1.65]]
    ]},
    {league:"WTA • Simulação",matches:[
      ["18:00","Ana Souza","Maria Lima",[1.70,2.20]]
    ]}
  ]
};

let sport="Futebol", balance=1000, selection=null;

function money(v){return v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"})}
function render(){
 document.getElementById("sportTitle").textContent=sport;
 document.getElementById("balance").textContent=money(balance);
 const box=document.getElementById("leagues"); box.innerHTML="";
 data[sport].forEach((l,li)=>{
  const el=document.createElement("div");el.className="league";
  el.innerHTML=`<div class="league-head"><span>${l.league}</span><span>${l.matches.length} jogos</span></div>`;
  l.matches.forEach((m,mi)=>{
   const marketNames=sport==="Futebol"?["Casa","Empate","Fora"]:["Casa","Fora"];
   const vals=m[3];
   const match=document.createElement("div");match.className="match";
   let markets="";
   vals.forEach((v,i)=>{
     markets+=`<div class="market"><div class="market-title">${marketNames[i]||"Mercado"}</div><div class="odds"><button class="odd back" onclick="selectBet(${li},${mi},${i},'Back')">${v.toFixed(2)}<small>BACK</small></button><button class="odd lay" onclick="selectBet(${li},${mi},${i},'Lay')">${(v+0.08).toFixed(2)}<small>LAY</small></button></div></div>`
   });
   match.innerHTML=`<div class="match-top"><div class="teams">${m[1]}<br>${m[2]}</div><div class="time">${m[0]}</div></div><div class="markets">${markets}</div>`;
   el.appendChild(match);
  });
  box.appendChild(el);
 });
 renderSlip();
}
function selectBet(li,mi,oi,type){
 const m=data[sport][li].matches[mi], names=sport==="Futebol"?["Casa","Empate","Fora"]:["Casa","Fora"];
 const odd=m[3][oi]+(type==="Lay"?0.08:0);
 selection={sport,game:m[1]+" x "+m[2],market:names[oi],type,odd};
 renderSlip();
}
function renderSlip(){
 const box=document.getElementById("slipItems");
 if(!selection){box.className="slip-empty";box.textContent="Selecione uma odd Back ou Lay.";document.getElementById("slipCount").textContent="0";document.getElementById("liability").textContent=money(0);return}
 box.className="";
 box.innerHTML=`<div class="slip-item"><b>${selection.game}</b><small>${selection.market} • ${selection.type} • Odd ${selection.odd.toFixed(2)}</small></div>`;
 document.getElementById("slipCount").textContent="1";
 updateLiability();
}
function updateLiability(){const stake=Number(document.getElementById("stake").value)||0;const r=selection&&selection.type==="Lay"?stake*(selection.odd-1):stake;document.getElementById("liability").textContent=money(r)}
document.getElementById("stake").addEventListener("input",updateLiability);
function placeBet(){
 if(!selection)return alert("Selecione uma operação primeiro.");
 const stake=Number(document.getElementById("stake").value)||0;
 const liability=selection.type==="Lay"?stake*(selection.odd-1):stake;
 if(stake<=0||liability>balance)return alert("Saldo fictício insuficiente.");
 balance-=liability;
 alert(`Operação simulada com sucesso!\\n${selection.type} • ${selection.game}\\nResponsabilidade: ${money(liability)}`);
 selection=null;render();
}
function resetBalance(){balance=1000;selection=null;render()}
document.querySelectorAll(".sport").forEach(b=>b.onclick=()=>{document.querySelectorAll(".sport").forEach(x=>x.classList.remove("active"));b.classList.add("active");sport=b.dataset.sport;selection=null;render()});
render();
